package com.daniel.medicaldevice.spo2.dim.elements;

public enum ElementsTypes {
	SYSTEM_TYPE, SYSTEM_MODEL, SYSTEM_ID, DEV_CONFIGURATION_ID, PRODUCTION_SPECIFICATION,SYSTEM_TYPE_SPEC_LIST;
}
